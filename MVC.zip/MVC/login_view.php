<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
</head>
<body>
    <h2>Đăng nhập</h2>
    <form action="login.php" method="post">
        <label for="username">Tên đăng nhập:</label><br>
        <input type="text" id="username" name="usernameForm"><br>
        <label for="password">Mật khẩu:</label><br>
        <input type="password" id="password" name="passwordForm"><br><br>
        <input type="submit" value="Đăng nhập">
    </form>
</body>
</html>
